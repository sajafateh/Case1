
package codewithbuilder;

public class Codewithbuilder {
    public static void main(String[] args) {
           
//         without the builder pattern
//        GameCharacter character = new GameCharacter(
//                "Ali",
//                "Warrior",
//                150,
//                "Sword",
//                "Heavy",
//                Arrays.asList("Slash", "Block")
//        );
//
//        System.out.println(character.getName());
//    }
//}
//        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
//   without the director 

        GameCharacter character = new RPGCharacterBuilder()
                .setName("Ali")
                .setType("Warrior")
                .setHealth(150)
                .setWeapon("Sword")
                .addSkill("Slash")
                .build();

        System.out.println(character.getName());


//   with the  director
CharacterDirector director = new CharacterDirector();
        GameCharacter warrior = director.createWarrior();

        System.out.println(warrior.getName());




    }
    
    
    
}