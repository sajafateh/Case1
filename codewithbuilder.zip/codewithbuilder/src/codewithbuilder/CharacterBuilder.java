
package codewithbuilder;
interface CharacterBuilder {
    CharacterBuilder setName(String name);
    CharacterBuilder setType(String type);
    CharacterBuilder setHealth(int hp);
    CharacterBuilder setWeapon(String weapon);
    CharacterBuilder setArmour(String armour);
    CharacterBuilder addSkill(String skill);
    GameCharacter build();
}
