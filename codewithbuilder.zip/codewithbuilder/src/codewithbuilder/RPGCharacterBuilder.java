
package codewithbuilder;
import java.util.ArrayList;
import java.util.List;

class RPGCharacterBuilder implements CharacterBuilder {

    private String name;
    private String type;
    private int health = 100; 
    private String weapon;
    private String armour;
    private List<String> skills = new ArrayList<>();

    @Override
    public CharacterBuilder setName(String name) {
        this.name = name;
        return this;
    }

    @Override
    public CharacterBuilder setType(String type) {
        this.type = type;
        return this;
    }

    @Override
    public CharacterBuilder setHealth(int hp) {
        this.health = hp;
        return this;
    }

    @Override
    public CharacterBuilder setWeapon(String weapon) {
        this.weapon = weapon;
        return this;
    }

    @Override
    public CharacterBuilder setArmour(String armour) {
        this.armour = armour;
        return this;
    }

    @Override
    public CharacterBuilder addSkill(String skill) {
        this.skills.add(skill);
        return this;
    }

    @Override
    public GameCharacter build() {
        if (name == null || type == null) {
            throw new IllegalStateException("Name and type are required");
        }

        return new GameCharacter(name, type, health, weapon, armour, skills);
    }
}