
//without the builder patternn
//package code1;
//
//import java.util.List;
//
// public class GameCharacter {
//    private final String name;
//    private final String type;
//    private final int health;
//    private final String weapon;
//    private final String armour;
//    private final List<String> skills;
//
//    public GameCharacter(String name, String type, int health,String weapon, String armour, List<String> skills) {
//                         
//
//        if (name == null || type == null) {
//            throw new IllegalArgumentException("Name and type are required");
//        }
//
//        this.name = name;
//        this.type = type;
//        this.health = health;
//        this.weapon = weapon;
//        this.armour = armour;
//        this.skills = List.copyOf(skills);
//    }
//
//    public String getName() { return name; }
//    public String getType() { return type; }
//    public int getHealth() { return health; }
//    public String getWeapon() { return weapon; }
//    public String getArmour() { return armour; }
//    public List<String> getSkills() { return skills; }
//}
//
//
//
//
//
//




package codewithbuilder;

import java.util.List;

class GameCharacter {
    private final String name;
    private final String type;
    private final int health;
    private final String weapon;
    private final String armour;
    private final List<String> skills;

    public GameCharacter(String name, String type, int health,
                         String weapon, String armour, List<String> skills) {

        this.name = name;
        this.type = type;
        this.health = health;
        this.weapon = weapon;
        this.armour = armour;
        this.skills = List.copyOf(skills);
    }

    public String getName() { return name; }
    public String getType() { return type; }
}


