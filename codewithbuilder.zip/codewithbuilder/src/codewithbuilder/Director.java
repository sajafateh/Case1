
package codewithbuilder;

class CharacterDirector {

    public GameCharacter createWarrior() {
        return new RPGCharacterBuilder()
                .setName("Default Warrior")
                .setType("Melee")
                .setHealth(150)
                .setWeapon("Sword")
                .setArmour("Heavy")
                .addSkill("Slash")
                .build();
    }
}
